<footer class="mt-auto">
    <div class="border-t border-gray-200 dark:border-gray-800 py-4">
        <p class="text-sm text-gray-500 dark:text-gray-400 text-center">
            &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.
        </p>
    </div>
</footer><?php /**PATH /home/navu/Data/Professional/Navigate/Clients/Projects/Laravel/inklusi-kerja/resources/views/layouts/footer.blade.php ENDPATH**/ ?>