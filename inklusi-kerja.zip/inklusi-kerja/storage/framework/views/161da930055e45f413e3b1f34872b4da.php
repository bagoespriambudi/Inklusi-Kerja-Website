<?php $__env->startPush('styles'); ?>
<style>
/* Layout */
body {
    font-family: 'Plus Jakarta Sans', sans-serif;
    background-color: #f8fafc;
}

.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
}

.main-content {
    flex: 1;
    margin-left: 250px;
    transition: margin 0.3s;
}

.content-wrapper {
    padding: 20px;
}

/* Sidebar */
.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    background: white;
    border-right: 1px solid #e5e7eb;
    z-index: 1000;
    transition: all 0.3s;
}

.sidebar-header {
    height: 60px;
    padding: 0 20px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #e5e7eb;
}

.sidebar-menu {
    list-style: none;
    padding: 20px 0;
    margin: 0;
}

.menu-header {
    padding: 10px 20px;
    font-size: 12px;
    text-transform: uppercase;
    color: #6b7280;
    font-weight: 600;
}

.menu-item a {
    display: flex;
    align-items: center;
    padding: 10px 20px;
    color: #374151;
    text-decoration: none;
    transition: all 0.3s;
}

.menu-item a i {
    margin-right: 10px;
    font-size: 18px;
}

.menu-item.active a,
.menu-item a:hover {
    background: #f3f4f6;
    color: #2563eb;
}

/* Navbar */
.navbar {
    height: 60px;
    background: white;
    border-bottom: 1px solid #e5e7eb;
    padding: 0 20px;
}

.search-form {
    max-width: 400px;
    width: 100%;
}

.sidebar-toggle {
    padding: 6px 12px;
    font-size: 20px;
    border: none;
    background: transparent;
}

/* Responsive */
@media (max-width: 991.98px) {
    .sidebar {
        margin-left: -250px;
    }

    .sidebar.show {
        margin-left: 0;
    }

    .main-content {
        margin-left: 0;
    }

    .search-form {
        display: none;
    }
}
</style>
<?php $__env->stopPush(); ?> <?php /**PATH /home/navu/Data/Professional/Navigate/Clients/Projects/Laravel/inklusi-kerja/resources/views/layouts/css.blade.php ENDPATH**/ ?>