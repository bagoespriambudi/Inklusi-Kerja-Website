<?php $__env->startSection('title', 'Add New Company'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="bg-gradient-to-r from-blue-600 to-blue-800 shadow-lg rounded-lg mb-8 p-8">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="font-bold text-2xl text-white mb-2">Add New Company</h2>
            <p class="text-blue-100">Create a new company profile in the system</p>
        </div>
        <a href="<?php echo e(route('dashboard.companies.index')); ?>" class="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-lg transition-colors duration-150 backdrop-blur-sm">
            <i class="bi bi-arrow-left"></i>
            <span>Back to List</span>
        </a>
    </div>
</div>

<?php if($errors->any()): ?>
    <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-8 rounded-lg">
        <div class="flex items-center">
            <div class="flex-shrink-0">
                <i class="bi bi-exclamation-triangle text-red-500"></i>
            </div>
            <div class="ml-3">
                <h3 class="text-red-800 font-medium">There were some problems with your input</h3>
                <div class="mt-2 text-red-700">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>


<!-- Create Company Form -->
<div class="bg-white shadow-xl rounded-xl">
    <div class="p-8">
        <form action="<?php echo e(route('dashboard.companies.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-8">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Company Name -->
                <div class="bg-gray-50 p-6 rounded-xl">
                    <label for="name" class="block text-sm font-semibold text-gray-700 mb-2">Company Name</label>
                    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" 
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-3 transition duration-150">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Website -->
                <div class="bg-gray-50 p-6 rounded-xl">
                    <label for="website" class="block text-sm font-semibold text-gray-700 mb-2">Website</label>
                    <input type="url" name="website" id="website" value="<?php echo e(old('website')); ?>" 
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-3 transition duration-150">
                    <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Location -->
                <div class="bg-gray-50 p-6 rounded-xl">
                    <label for="location" class="block text-sm font-semibold text-gray-700 mb-2">Location</label>
                    <input type="text" name="location" id="location" value="<?php echo e(old('location')); ?>" 
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-3 transition duration-150">
                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Industry -->
                <div class="bg-gray-50 p-6 rounded-xl">
                    <label for="industry" class="block text-sm font-semibold text-gray-700 mb-2">Industry</label>
                    <input type="text" name="industry" id="industry" value="<?php echo e(old('industry')); ?>" 
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-3 transition duration-150">
                    <?php $__errorArgs = ['industry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Company Size -->
                <div class="bg-gray-50 p-6 rounded-xl">
                    <label for="size" class="block text-sm font-semibold text-gray-700 mb-2">Company Size</label>
                    <select name="size" id="size" class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-3 transition duration-150">
                        <option value="">Select size</option>
                        <option value="1-10" <?php echo e(old('size') === '1-10' ? 'selected' : ''); ?>>1-10 employees</option>
                        <option value="11-50" <?php echo e(old('size') === '11-50' ? 'selected' : ''); ?>>11-50 employees</option>
                        <option value="51-200" <?php echo e(old('size') === '51-200' ? 'selected' : ''); ?>>51-200 employees</option>
                        <option value="201-500" <?php echo e(old('size') === '201-500' ? 'selected' : ''); ?>>201-500 employees</option>
                        <option value="501-1000" <?php echo e(old('size') === '501-1000' ? 'selected' : ''); ?>>501-1000 employees</option>
                        <option value="1000+" <?php echo e(old('size') === '1000+' ? 'selected' : ''); ?>>1000+ employees</option>
                    </select>
                    <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Status -->
                <div class="bg-gray-50 p-6 rounded-xl">
                    <label for="status" class="block text-sm font-semibold text-gray-700 mb-2">Status</label>
                    <select name="status" id="status" class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-3 transition duration-150">
                        <option value="pending" <?php echo e(old('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="verified" <?php echo e(old('status') === 'verified' ? 'selected' : ''); ?>>Verified</option>
                        <option value="rejected" <?php echo e(old('status') === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Logo -->
            <div class="bg-gray-50 p-6 rounded-xl">
                <label for="logo" class="block text-sm font-semibold text-gray-700 mb-2">Company Logo</label>
                <input type="file" name="logo" id="logo" accept="image/*" 
                    class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-3 file:px-6 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 transition duration-150">
                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Description -->
            <div class="bg-gray-50 p-6 rounded-xl">
                <label for="description" class="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                <textarea name="description" id="description" rows="4" 
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-3 transition duration-150"><?php echo e(old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <!-- Featured Status -->
            <div class="bg-gray-50 p-6 rounded-xl">
                <div class="flex items-center">
                    <input type="checkbox" name="is_featured" id="is_featured" value="1" <?php echo e(old('is_featured') ? 'checked' : ''); ?>

                        class="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500 transition duration-150">
                    <label for="is_featured" class="ml-3 block text-sm font-medium text-gray-700">
                        Featured Company
                    </label>
                </div>
                <p class="mt-2 text-sm text-gray-500">Featured companies appear prominently throughout the platform</p>
            </div>

            <div class="flex justify-end gap-4">
                <a href="<?php echo e(route('dashboard.companies.index')); ?>" class="inline-flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-3 rounded-lg transition-colors duration-150">
                    <i class="bi bi-arrow-left"></i>
                    <span>Cancel</span>
                </a>
                <button type="submit" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors duration-150">
                    <i class="bi bi-check-lg"></i>
                    <span>Create Company</span>
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/navu/Data/Professional/Navigate/Clients/Projects/Laravel/inklusi-kerja/resources/views/dashboard/company/create.blade.php ENDPATH**/ ?>