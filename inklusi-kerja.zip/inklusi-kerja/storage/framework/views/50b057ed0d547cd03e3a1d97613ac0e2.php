<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar Toggle
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            
            // Handle backdrop on mobile
            if (window.innerWidth < 992) {
                if (sidebar.classList.contains('show')) {
                    const backdrop = document.createElement('div');
                    backdrop.className = 'sidebar-backdrop';
                    backdrop.style.cssText = `
                        position: fixed;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        background: rgba(0,0,0,0.5);
                        z-index: 999;
                    `;
                    document.body.appendChild(backdrop);
                    
                    backdrop.addEventListener('click', function() {
                        sidebar.classList.remove('show');
                        backdrop.remove();
                    });
                } else {
                    const backdrop = document.querySelector('.sidebar-backdrop');
                    if (backdrop) backdrop.remove();
                }
            }
        });
    }

    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 992) {
            const backdrop = document.querySelector('.sidebar-backdrop');
            if (backdrop) backdrop.remove();
        }
    });
});
</script>
<?php $__env->stopPush(); ?> <?php /**PATH /home/navu/Data/Professional/Navigate/Clients/Projects/Laravel/inklusi-kerja/resources/views/layouts/script.blade.php ENDPATH**/ ?>