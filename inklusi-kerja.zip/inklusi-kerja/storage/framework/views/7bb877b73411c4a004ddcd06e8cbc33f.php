<nav class="sticky top-0 z-30 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
    <div class="px-4 sm:px-6 py-1">
        <div class="flex h-14 items-center justify-between gap-4">
            <!-- Left side -->
            <div class="flex items-center gap-4">
                <button type="button" 
                        class="text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300 lg:hidden"
                        @click="sidebarOpen = !sidebarOpen">
                    <i class="bi bi-list text-2xl"></i>
                </button>

                <!-- Search -->
                <div class="hidden lg:block relative">
                    <input type="text" 
                           placeholder="Search..." 
                           class="w-72 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-gray-300 text-sm rounded-lg pl-10 pr-4 h-9 focus:outline-none focus:ring-1 focus:ring-gray-200 dark:focus:ring-gray-700 focus:border-gray-200 dark:focus:border-gray-700">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="bi bi-search text-gray-400 dark:text-gray-500 text-sm"></i>
                    </div>
                </div>
            </div>

            <!-- Right side -->
            <div class="flex items-center gap-3">
                <!-- Theme Toggle -->
                <button type="button" 
                        @click="toggleTheme()"
                        class="p-1.5 text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
                    <i class="bi" :class="isDark ? 'bi-sun' : 'bi-moon'"></i>
                </button>

                <!-- Notifications -->
                <div class="relative" x-data="{ open: false }" @click.outside="open = false">
                    <button type="button" 
                            class="p-1.5 text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
                            @click="open = !open">
                        <span class="sr-only">View notifications</span>
                        <div class="relative">
                            <i class="bi bi-bell text-xl"></i>
                            <div class="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[11px] font-medium text-white">3</div>
                        </div>
                    </button>

                    <!-- Notifications dropdown -->
                    <div x-show="open" 
                         x-transition:enter="transition ease-out duration-100"
                         x-transition:enter-start="transform opacity-0 scale-95"
                         x-transition:enter-end="transform opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-75"
                         x-transition:leave-start="transform opacity-100 scale-100"
                         x-transition:leave-end="transform opacity-0 scale-95"
                         class="absolute right-0 mt-2 w-80 origin-top-right rounded-lg bg-white dark:bg-gray-800 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
                         style="display: none;">
                        <div class="border-b border-gray-200 dark:border-gray-700 px-4 py-3">
                            <h6 class="text-sm font-semibold text-gray-900 dark:text-white">Notifications</h6>
                        </div>
                        <div class="max-h-[calc(100vh-20rem)] overflow-y-auto divide-y divide-gray-200 dark:divide-gray-700">
                            <a href="#" class="block px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                <p class="text-sm text-gray-600 dark:text-gray-300">Notification 1</p>
                                <p class="mt-1 text-xs text-gray-400 dark:text-gray-500">1 hour ago</p>
                            </a>
                            <a href="#" class="block px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                <p class="text-sm text-gray-600 dark:text-gray-300">Notification 2</p>
                                <p class="mt-1 text-xs text-gray-400 dark:text-gray-500">2 hours ago</p>
                            </a>
                        </div>
                        <div class="border-t border-gray-200 dark:border-gray-700">
                            <a href="#" class="block px-4 py-3 text-sm text-blue-600 dark:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                View all notifications
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Profile dropdown -->
                <div class="relative" x-data="{ open: false }" @click.outside="open = false">
                    <button type="button" 
                            class="flex items-center gap-2 p-1.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
                            @click="open = !open">
                        <img src="<?php echo e(\App\Helpers\UserHelper::getAvatar(Auth::user())); ?>" 
                             class="h-7 w-7 rounded-full border border-gray-200 dark:border-gray-700" 
                             alt="">
                        <div class="hidden lg:block text-left">
                            <div class="text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(Auth::user()->name); ?></div>
                            <div class="text-xs text-gray-500 dark:text-gray-400 mt-0.5"><?php echo e(Auth::user()->email); ?></div>
                        </div>
                        <i class="bi bi-chevron-down text-gray-400 text-sm"></i>
                    </button>

                    <!-- Profile dropdown menu -->
                    <div x-show="open"
                         x-transition:enter="transition ease-out duration-100"
                         x-transition:enter-start="transform opacity-0 scale-95"
                         x-transition:enter-end="transform opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-75"
                         x-transition:leave-start="transform opacity-100 scale-100"
                         x-transition:leave-end="transform opacity-0 scale-95"
                         class="absolute right-0 mt-2 w-48 origin-top-right rounded-lg bg-white dark:bg-gray-800 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none divide-y divide-gray-200 dark:divide-gray-700"
                         style="display: none;">
                        <div class="py-1">
                            <a href="#" class="group flex items-center gap-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                <i class="bi bi-person text-gray-400 dark:text-gray-500 group-hover:text-blue-500 dark:group-hover:text-blue-500"></i>
                                Profile
                            </a>
                            <a href="#" class="group flex items-center gap-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                <i class="bi bi-gear text-gray-400 dark:text-gray-500 group-hover:text-blue-500 dark:group-hover:text-blue-500"></i>
                                Settings
                            </a>
                        </div>
                        <div class="py-1">
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="group flex w-full items-center gap-2 px-4 py-2 text-sm text-red-600 dark:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/50">
                                    <i class="bi bi-box-arrow-right text-red-400 dark:text-red-500 group-hover:text-red-600 dark:group-hover:text-red-400"></i>
                                    Logout
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav> <?php /**PATH /home/navu/Data/Professional/Navigate/Clients/Projects/Laravel/inklusi-kerja/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>