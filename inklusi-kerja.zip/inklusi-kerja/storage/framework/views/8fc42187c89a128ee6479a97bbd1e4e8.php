<aside class="fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 pb-10 overflow-y-auto transform lg:translate-x-0 lg:static lg:inset-0 transition-transform duration-200"
       :class="{'translate-x-0': sidebarOpen, '-translate-x-full': !sidebarOpen}">
    <!-- Logo -->
    <div class="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-800">
        <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-2">
            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo" class="h-8 w-auto">
            <span class="text-lg font-semibold text-gray-900 dark:text-white"><?php echo e(config('app.name')); ?></span>
        </a>
    </div>

    <!-- Navigation -->
    <nav class="p-4 space-y-6">
        <!-- Dashboard -->
        <div>
            <a href="<?php echo e(route('home')); ?>" 
               class="flex items-center gap-3 px-3 py-2.5 text-sm <?php echo e(Request::is('home') ? 'text-blue-600 dark:text-blue-500 bg-blue-50 dark:bg-blue-900/50 font-semibold rounded-lg' : 'text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg'); ?>">
                <i class="bi bi-house text-xl"></i>
                <span>Dashboard</span>
            </a>
        </div>

        <?php if(Auth::user()->role === 'admin'): ?>
        <!-- Admin Menu -->
        <div>
            <h6 class="px-3 mb-3 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Management</h6>
            <div class="space-y-1">
                <a href="<?php echo e(route('dashboard.companies.index')); ?>" class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg">
                    <i class="bi bi-building text-xl"></i>
                    <span>Companies</span>
                </a>

                <a href="#" class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg">
                    <i class="bi bi-briefcase text-xl"></i>
                    <span>Jobs</span>
                </a>

                <a href="#" class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg">
                    <i class="bi bi-people text-xl"></i>
                    <span>Users</span>
                </a>
            </div>
        </div>
        <?php else: ?>
        <!-- Job Seeker Menu -->
        <div>
            <h6 class="px-3 mb-3 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Job Seeker</h6>
            <div class="space-y-1">
                <a href="#" class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg">
                    <i class="bi bi-search text-xl"></i>
                    <span>Find Jobs</span>
                </a>

                <a href="#" class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg">
                    <i class="bi bi-file-text text-xl"></i>
                    <span>My Applications</span>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- Account Menu -->
        <div>
            <h6 class="px-3 mb-3 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Account</h6>
            <div class="space-y-1">
                <a href="#" class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg">
                    <i class="bi bi-person text-xl"></i>
                    <span>Profile</span>
                </a>

                <a href="#" class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-500 hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg">
                    <i class="bi bi-gear text-xl"></i>
                    <span>Settings</span>
                </a>
            </div>
        </div>
    </nav>
</aside> <?php /**PATH /home/navu/Data/Professional/Navigate/Clients/Projects/Laravel/inklusi-kerja/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>