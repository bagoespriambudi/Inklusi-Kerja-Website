<?php $__env->startSection('title', 'Companies'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="bg-white shadow-sm border border-gray-200 rounded-lg mb-6 p-6">
    <div class="flex items-center justify-between">
        <h2 class="font-semibold text-xl text-gray-800">Companies</h2>
        <a href="<?php echo e(route('dashboard.companies.create')); ?>" class="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-150">
            <i class="bi bi-plus-lg"></i>
            <span>Add Company</span>
        </a>
    </div>
</div>

<!-- Companies List -->
<div class="bg-white shadow-sm border border-gray-200 rounded-lg">
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-gray-50 border-b border-gray-200">
                <tr>
                    <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
                    <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                    <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Industry</th>
                    <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Active Jobs</th>
                    <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 flex-shrink-0 rounded-full bg-gray-100 flex items-center justify-center">
                                <?php if($company->logo): ?>
                                    <img src="<?php echo e(asset('storage/' . $company->logo)); ?>" alt="<?php echo e($company->name); ?>" class="w-10 h-10 rounded-full">
                                <?php else: ?>
                                    <i class="bi bi-building text-gray-500"></i>
                                <?php endif; ?>
                            </div>
                            <div>
                                <div class="font-medium text-gray-900"><?php echo e($company->name); ?></div>
                                <div class="text-sm text-gray-500"><?php echo e($company->email); ?></div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo e($company->location); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo e($company->industry); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo e($company->jobs_count ?? 0); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo e($company->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                            <?php echo e($company->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo e(route('dashboard.companies.edit', $company)); ?>" class="text-blue-600 hover:text-blue-900">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?php echo e(route('dashboard.companies.destroy', $company)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure you want to delete this company?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                        No companies found.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <?php if($companies->hasPages()): ?>
    <div class="px-6 py-4 border-t border-gray-200">
        <?php echo e($companies->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/navu/Data/Professional/Navigate/Clients/Projects/Laravel/inklusi-kerja/resources/views/dashboard/company/index.blade.php ENDPATH**/ ?>